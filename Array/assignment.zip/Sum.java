package Array;

public class Sum {
public static void main(String[] args) {
	int[]arr= new int[]{10,10,10,10};
	int sum=0;
	for(int i=0;i<arr.length;i++) {
		 sum=sum+arr[i];
	}System.out.println(+sum);
}
}
